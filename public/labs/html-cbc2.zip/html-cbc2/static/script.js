document.addEventListener("DOMContentLoaded", function () {
    
    const key=new TextEncoder().encode("inikuncinyayasir");
    
    
//ecnrypt function to encrypt username and password
    async function encrypt(data){
        const encoder = new TextEncoder(); //textencoder converts input into a bytearray
        const encodedData = encoder.encode(data); // Convert input into bytes
        const iv = crypto.getRandomValues(new Uint8Array(16)); // Generate a new IV for each encryption


        const enckey = await crypto.subtle.importKey(
            "raw",
            key,
            { name: "AES-CBC" },
            false,
            ["encrypt"]
        );

        const encryptedData = await crypto.subtle.encrypt(
            { name: "AES-CBC", iv: iv },
            enckey,
            encodedData
        );

        return { encrypted: bufferToHex(encryptedData), iv: bufferToHex(iv) };
        // we want to return a object 
        // why dont use this: return bufferToHex(encryptedData); ?
        // -  Flask won't be able to decrypt the data correctly, because AES-CBC decryption requires the same IV used during encryption.
        // -  If you return only the encrypted data, Flask will use a random IV
        // -  If you return the IV, Flask will use the same IV used during encryption
        // converts the encrypted data from binary (ArrayBuffer) to a Hexadecimal string

    }
//decrypt function for decrypt response
    /*async function decrypt(encryptedHex, ivHex) {
        const encryptedData = hexToBuffer(encryptedHex); // Convert hex to ArrayBuffer
        const iv = hexToBuffer(ivHex); // Convert IV hex to ArrayBuffer
    
        const decryptionKey = await crypto.subtle.importKey(
            "raw",
            key,
            { name: "AES-CBC" },
            false,
            ["decrypt"]
        );
    
        const decryptedData = await crypto.subtle.decrypt(
            { name: "AES-CBC", iv: iv }, // Use IV from encryption
            decryptionKey,
            encryptedData
        );
    
        return new TextDecoder().decode(decryptedData); 
        // Convert decrypted bytes to string        
    }*/

//(FUNCTION)converting the ArrayBuffer to hex string --> Encryption
    function bufferToHex(buffer) {
        return [...new Uint8Array(buffer)].map(b => b.toString(16).padStart(2, '0')).join('');
    }
//explanation:
    //.map(b => b.toString(16)) converts each byte (b) into a Hex string.
    //.padStart(2, '0') ensures each Hex byte is always 2 characters long.
    //join --> Joins all hex values into one long string.

//why is this needed?
    //To make the encrypted data readable and transferable, we use bufferToHex() to convert the binary data into a Hex string.
    //AES-CBC in JavaScript, crypto.subtle.encrypt() returns raw binary data (ArrayBuffer)
    // -Cannot be stored as text in a database.
    // -Cannot be directly sent over HTTP

//(FUNCTION)converting hex to ArrayBuffer --> Decryption
    function hexToBuffer(hex) {
        const bytes = new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)));
        return bytes.buffer;
    }
//explanation:
    // hex.match(/.{1,2}/g) → Splits the hex string into pairs of two characters (each representing a byte).
    // .map(byte => parseInt(byte, 16)) → Converts each hex pair into a decimal number.
    // new Uint8Array([...]) → Creates a Uint8Array, which is required for cryptographic functions.
    // .buffer → Returns the ArrayBuffer representation of the Uint8Array, which is needed for AES decryption.
//why is this needed?
    // encrypted data from the backend, it will be in hexadecimal format
    // for the crypto.subtle.decrypt() function to work, you must convert it back to an ArrayBuffer.


// Handle login form
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", async function (event) {
            //we add async in front of function so line 58 and 59 can use await 
            event.preventDefault(); // Prevent page reload
            
            const lusername = document.getElementById("logusername").value;
            const lpassword = document.getElementById("logpassword").value;
            
            console.log("Username:", lusername);
            console.log("Password:", lpassword);

            const encryptedUsername = await encrypt(lusername)
            const encryptedPassword = await encrypt(lpassword)

             //To check or debugging use these: 
                //console.log("Username:", lusername);
                //console.log("Password:", lpassword);
            
            //send data to a backend API using fetch()
            //fetch() is used to send the login request to the backend.
            fetch("/login.html", {
                method: "POST",
                headers: { "Content-Type": "application/json" },  // <-- Ensure this is set
                body: JSON.stringify({ 
                    username: encryptedUsername.encrypted, 
                    password: encryptedPassword.encrypted,
                    iv: encryptedUsername.iv,  // ✅ IV for username
                    ivpw: encryptedPassword.iv  // ✅ IV for password
                                        
                })
                
            }).then(response => response.json())
            // .json() parses the response body into a JavaScript object.
            // why?backend sends data in JSON format, but JavaScript needs an object to work with it.
            .then(async data => {
                console.log("Server Response:", data); // Debugging
                if (data.message === "success") {
                    window.location.href = data.redirect; // Redirect to Flask home route
                } else {
                    alert("Login failed! Check your credentials.");
                }
            })
            
            
            // logic if success go to home.html
              .catch(error => console.error("Error:", error));
            //send encrypted username, encrypted password, and iv to backend (flask)
            //JSON.stringify({...}) --> to make flask easily parse using request.json
            });
    }

// Handle register form
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", async function (event) {
            event.preventDefault();
            
            const rusername = document.getElementById("regusername").value;
            const rpassword = document.getElementById("regpassword").value;
            
            const regencryptedUsername = await encrypt(rusername)
            const regencryptedPassword = await encrypt(rpassword)
            //To check or debugging use these: 
                //console.log("Username:", rusername);
                //console.log("Password:", rpassword);
            
            //send data to a backend API using fetch()
            fetch("/register.html", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    username: regencryptedUsername.encrypted, 
                    password: regencryptedPassword.encrypted, 
                    iv: regencryptedUsername.iv,
                    ivpw: regencryptedPassword.iv 
                })
                
            }).then(response => response.json())
              .then(data => console.log(data))
              .catch(error => console.error("Error:", error));
        });
    }

});