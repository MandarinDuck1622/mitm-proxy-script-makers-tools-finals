from flask import Flask, request, jsonify, render_template, send_from_directory
import pandas as pd  # For Excel
import os
import binascii
from Crypto.Cipher import AES
import base64
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Excel file path
EXCEL_FILE = "database.xlsx"

# AES Key (16 bytes)
KEY = b"inikuncinyayasir"

# Ensure the Excel file exists
if not os.path.exists(EXCEL_FILE):
    df = pd.DataFrame(columns=["Username", "Password", "IV","IVPW"])  # Fixed column names
    df.to_excel(EXCEL_FILE, index=False)

# Function to read the Excel file
def read_excel():
    return pd.read_excel(EXCEL_FILE)

# Function to write to the Excel file
def write_excel(df):
    df.to_excel(EXCEL_FILE, index=False)

def decrypt_aes_cbc(encrypted_hex, iv_hex):
    """Decrypt AES-CBC encrypted data."""
    try:
        #debugging
        print(f"Decrypting: {encrypted_hex} with IV: {iv_hex}")
        
        encrypted_bytes = binascii.unhexlify(encrypted_hex)
        iv = binascii.unhexlify(iv_hex)

        cipher = AES.new(KEY, AES.MODE_CBC, iv)
        decrypted_padded = cipher.decrypt(encrypted_bytes)
        
        # Remove PKCS7 padding
        pad_len = decrypted_padded[-1]
        if pad_len > 16:  # Padding should be between 1-16
            raise ValueError("Invalid padding")
        
        return decrypted_padded[:-pad_len].decode('utf-8')
    except Exception as e:
        print(f"Decryption Error: {e}")
        return None

def load_users():
    """Load users from Excel file."""
    try:
        df = pd.read_excel(EXCEL_FILE)

        # Ensure IV and IVPW columns exist (older records may not have them)
        if "IV" not in df.columns:
            df["IV"] = None
        if "IVPW" not in df.columns:
            df["IVPW"] = None

        # Return dictionary with username, password, and both IVs
        return {
            row["Username"]: {
                "password": row["Password"],
                "iv": base64.b64decode(row["IV"]),  # Decode IV dari base64
                "ivpw": base64.b64decode(row["IVPW"])  # Decode IVPW dari base64
            }
            for _, row in df.iterrows()
        }
    except Exception as e:
        print("Error reading Excel:", e)
        return {}

import base64

def save_user(username, password, iv, ivpw):
    """Save user to Excel file."""
    try:
        df = pd.read_excel(EXCEL_FILE)

        # Debugging: Print sebelum menyimpan user baru
        print("Before saving:", df)

        # Cek apakah user sudah ada
        if username in df["Username"].values:
            print("User already exists! Not saving.")
            return False  # User sudah ada

        # ✅ Pastikan IV dikonversi ke bytes sebelum base64 encode
        iv_bytes = base64.b64decode(iv) if isinstance(iv, str) else iv
        ivpw_bytes = base64.b64decode(ivpw) if isinstance(ivpw, str) else ivpw

        new_user = pd.DataFrame({
            "Username": [str(username)],
            "IV": [base64.b64encode(iv_bytes).decode()],  # Simpan IV sebagai base64 string
            "Password": [str(password)],  
            "IVPW": [base64.b64encode(ivpw_bytes).decode()]  # Simpan IVPW sebagai base64 string
        })

        # Tambahkan user baru ke database
        df = pd.concat([df, new_user], ignore_index=True)

        # Debugging: Print setelah menyimpan user baru
        print("After saving:", df)

        df.to_excel(EXCEL_FILE, index=False)
        print("User saved successfully!")
        return True  # Berhasil
    except Exception as e:
        print("Error saving user:", e)
        return False



@app.route('/')
def login_page():
    return render_template("login.html")

@app.route('/login.html')
def login1_page():
    return render_template("login.html")

@app.route('/login.html', methods=['POST'])
def login():
    """Handle login requests."""
    data = request.json
    print("login data",data)
    encrypted_username = data.get("username")
    encrypted_password = data.get("password")
    iv = data.get("iv")  # 🔹 IV for username decryption
    ivpw = data.get("ivpw")  # 🔹 IV for password decryption

    if not all([encrypted_username, encrypted_password, iv, ivpw]):
        print("Missing Data")
        return jsonify({"message": "error", "error": "Missing data"}), 400

    try:
        users_db = load_users()
        print(users_db)
        decrypted_username = decrypt_aes_cbc(encrypted_username, iv)
        print(f"Decrypted Username: {decrypted_username}")#ini denugging sir

        
        if decrypted_username not in users_db:
            print("User not found in database")
            return jsonify({"message": "error", "error": "User not found"}), 400
        
        #stored_iv = users_db[encrypted_username]["iv"]  # Get stored IV for username
        #stored_ivpw = users_db[encrypted_username]["ivpw"]  # Get stored IV for password

        # Decrypt username using the IV sent from frontend
        #username = decrypt_aes_cbc(encrypted_username, stored_iv)

        #if decrypted_username is None or username not in users_db:
            #return jsonify({"message": "error", "error": "User not found"}), 400

        # Retrieve stored IVPW from database and decrypt password
        
        stored_ivpw = users_db[decrypted_username]["ivpw"]  # ✅ Get stored IVPW
        print(stored_ivpw) #check lagii geys
        decrypted_password = decrypt_aes_cbc(encrypted_password, ivpw)  # ✅ Use stored IVPW
        print(decrypted_password) #buat checking 
        if decrypted_password is None or users_db[decrypted_username]["password"] != decrypted_password:
            return jsonify({"message": "error", "error": "Invalid credentials"}), 401

        return jsonify({"message": "success", "redirect": "/home"})
    except Exception as e:
        return jsonify({"message": "error", "error": str(e)}), 500


@app.route('/register.html', methods=['GET', 'POST'])
def register_page():
    if request.method == 'GET':
        return render_template("register.html")  # Serve the register page

    # If POST, process registration
    data = request.json
    encrypted_username = data.get("username")
    encrypted_password = data.get("password")
    iv = data.get("iv")
    ivpw=data.get("ivpw")

    
    if not all([encrypted_username, encrypted_password, iv, ivpw]):
        print("Missing Data") #buat debugging
        return jsonify({"message": "error", "error": "Missing data"}), 400

    try:
        username = decrypt_aes_cbc(encrypted_username, iv)
        password = decrypt_aes_cbc(encrypted_password, ivpw)

        if username is None or password is None:
            return jsonify({"message": "error", "error": "Decryption failed"}), 400

        users_db = load_users()
        
        if username in users_db:
            return jsonify({"message": "error", "error": "User already exists"}), 409

        if save_user(username, password, iv, ivpw):
            return jsonify({"message": "success", "redirect": "/login"})
        else:
            return jsonify({"message": "error", "error": "User already exists"}), 409
    except Exception as e:
        return jsonify({"message": "error", "error": str(e)}), 500


# Serve static files (JS, CSS)
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)
@app.route('/home')
def home():
    return render_template("home.html")  # Make sure home.html is inside /templates/


if __name__ == '__main__':
    app.run(host="127.0.0.1", port=5000, debug=True, ssl_context=('cert.pem', 'key.pem'))
